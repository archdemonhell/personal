# Gr3eNoX
Gr3eNoX Exploit Scanner V1.1 

run the Gr3eNoX Exploit Scanner V1.1 tool on your leptop or linux turn off your anti-virus on leptop
