# Havij

Havij is an automated SQL Injection tool that helps penetration testers to find and exploit SQL Injection vulnerabilities on a web page. It's a completely automated SQL Injection tool and it is dispersed by ITSecTeam, an Iranian security organization. The name Havij signifies "carrot", which is the apparatus' symbol.

 # SQL injection software
 windows supported only 
 *Turn off our defender control 
 *open it as administrator
 *find vulnerable point like website link ending with a parameter and an integer, copy the link and give it to havij it will dumb databases
 
 


# file password: darknet123
