I did a site weakness test on the web scb with SQLi technique, and managed to find the database, table, column and data with the inject url. There's also a web symlink.

By doing a bug test on the web scb, I got CMS admin login on the website ruangcarlo with default password.

Immediately fix ur website!

Archdemon | B4CKD00R CR45H
Reward Me
https://saweria.co/archdemonhell